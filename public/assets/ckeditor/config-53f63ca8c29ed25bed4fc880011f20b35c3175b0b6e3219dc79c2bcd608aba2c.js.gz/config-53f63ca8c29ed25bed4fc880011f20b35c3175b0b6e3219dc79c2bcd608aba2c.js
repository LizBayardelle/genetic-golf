CKEDITOR.config.toolbar_mini = [
      ["Bold","Italic","Underline","Strike"],
      ["Link", "Unlink"],
      ["Image", "HorizontalRule"],
      ["NumberedList","BulletedList","-","Outdent","Indent"],
  ];
